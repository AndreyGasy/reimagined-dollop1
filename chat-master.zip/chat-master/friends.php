<?
header("Location: http://capitalcity.oldbk.com".$_SERVER["REQUEST_URI"]);

?>