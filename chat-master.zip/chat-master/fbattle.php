<?
header("Location: http://capitalcity.oldbk.com/fbattle.php");
?>