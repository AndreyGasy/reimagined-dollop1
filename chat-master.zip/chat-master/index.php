<?
header("Location: http://oldbk.com");
?>